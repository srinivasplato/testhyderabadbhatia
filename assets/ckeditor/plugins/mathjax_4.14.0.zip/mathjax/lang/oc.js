/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'oc', {
	title: 'Formulas matematicas en TeX',
	button: 'Matematicas',
	dialogInput: 'Sasir la formula TeX aicí',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'Documentacion de TeX',
	loading: 'cargament...',
	pathName: 'matematicas'
} );
