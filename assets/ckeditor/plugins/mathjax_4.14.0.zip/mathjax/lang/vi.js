/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'vi', {
	title: 'Toán học bằng TeX',
	button: 'Toán',
	dialogInput: 'Nhập mã TeX ở đây',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'Tài liệu TeX',
	loading: 'đang nạp...',
	pathName: 'toán'
} );
