<?php
class Registermodel extends CI_Model
{

    
      public function all_users($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'name'
        );
        $search_1 = array
        (
             1 => 'users.name',
            2 => 'users.mobile',
            3 => 'users.email_id',
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] );
        }
        if($getcount)
        {
            return $this->db->select('id')->from('users')->where('delete_status', 1)->order_by('id','desc')->get()->num_rows();
        }
        else
        {
 $this->db->select('*')->from('users')->where('delete_status', 1)->order_by('id','desc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }    

    /*---------- /users ------------*/

    public function usersList(){
        $this->db->select('users.*');
        $this->db->where('delete_status','1');
        $query = $this->db->get('users');      
        return $query->result_array();
    }
    public function get_examIds($user_id){
        $this->db->select('DISTINCT(exam_id),payment_type');
        $this->db->where('user_id',$user_id);
        $this->db->where('delete_status','1');
        $query = $this->db->get('users_exams');      
        return $query->result_array();
    }

    public function getExams($exam_ids){
        if(!empty($exam_ids)){
            foreach($exam_ids as $exam){
                    $e_ids[]=$exam['exam_id'];
            }
        $this->db->select('GROUP_CONCAT(name) as course_names');
        $this->db->where_in('id',$e_ids);
        $this->db->where('delete_status','1');
        $query = $this->db->get('exams');  
       // echo $this->db->last_query();    
        return $query->row_array();
        }else{ return array('course_names'=> '');}
        
    }
   public function getExamPaymetTypes($exam_ids,$user_id){
        if(!empty($exam_ids)){
            foreach($exam_ids as $exam){
                    $e_ids=$exam['exam_id'];
            }
        $this->db->select('GROUP_CONCAT(payment_type) as payment_type');
        $this->db->where_in('id',$e_ids);
        $this->db->where('user_id',$user_id);
        $this->db->where('delete_status','1');
        $query = $this->db->get('users_exams');      
        return $query->row_array();
        }else{ return array('payment_type'=> '');}
        
    }
    public function getUserExams($user_id){

        $query="select ue.id,ue.payment_type,u.id as user_id,u.name,u.mobile,e.name as course,e.id as exam_id from users_exams ue inner join exams e on e.id=ue.exam_id inner join users u on u.id=ue.user_id where ue.user_id='".$user_id."' and e.delete_status=1 ";
       // echo $query;exit;
       $result= $this->db->query($query)->result_array();
       return $result;
    }

    public function getUserswithCourse($course_id){
        $this->db->select('users.*,(select count(id) from users_exams where users_exams.user_id=users.id and users_exams.exam_id='.$course_id.') as course_status');
        $this->db->where('delete_status','1');
        $query = $this->db->get('users');      
        return $query->result_array();
    }

    public function checkUserswithCourse($course_id,$user){
        $this->db->select('*');
        $this->db->where('exam_id',$course_id);
         $this->db->where('user_id',$user);
          $this->db->where('delete_status','1');
        $query = $this->db->get('users_exams');      
        return $query->row_array();
    }
    
    function getUsers($search){
      //  $this->db->select('name','mobile');
        $this->db->like('name', $search);
        $this->db->or_like('mobile', $search);
          $query = $this->db->get('users');
        return $query->result();
    }
     function getExamCatids($tquiz_id) {
        $this->db->where('id',$tquiz_id);
        $query = $this->db->get('test_series_quiz');
      return $query->result();
    }
     function getUserTests($uid){
        $this->db->select('qa.*,e.*,qt.*');
            $this->db->from('quiz_answers qa');
            $this->db->join('exams e','e.id = qa.course_id');
            $this->db->join('users u','u.id= qa.user_id');
            //$this->db->join('subjects s','s.id= qa.subject_id');
            $this->db->join('quiz_topics qt','qt.id= qa.topic_id');
            $this->db->where('e.delete_status','1');
           // $this->db->where('s.delete_status','1');
            $this->db->where('u.delete_status','1');
            $this->db->where('u.id',$uid);
            //$this->db->group_by('qa.topic_id');
            $this->db->order_by('qa.id asc');
          //  $this->db->limit($limit, $start);
            $res = $this->db->get();
            return $res->result_array();
       }


    public function get_users()
    {
        $this->db->order_by('id', 'desc');
        $query = $this->db->get('users');      
        return $query->result();
    }
public function get_user_data($id){
        $this->db->select('*');
        $this->db->where('id',$id);
        //$this->db->where('delete_status','1');
        $query = $this->db->get('users');      
        $result=$query->row_array();
        return $result;
}
public function get_user_exams($id){
        $this->db->select('*');
        $this->db->where('user_id',$id);
        //$this->db->where('delete_status','1');
        $query = $this->db->get('users_exams');      
        $result=$query->result_array();
        return $result;
}
    public function check_useremail($email)
    {
        $this->db->select('id','email_id');
        $this->db->where('email_id',$email);
        $this->db->where('delete_status','1');

        $query = $this->db->get('users');      
        $result=$query->row_array();
        if(empty($result)){
            return 0;
        }else{
            return 1;
        }
    }

     public function check_usermobile($mobile)
    {
        $this->db->select('id','mobile');
        $this->db->where('mobile',$mobile);
        $this->db->where('delete_status','1');
        $query = $this->db->get('users');      
        $result=$query->row_array();
        if(empty($result)){
            return 0;
        }else{
            return 1;
        }
    }

    public function delete_user($user_id)
    {        
        $this->db->where('id', $user_id);
        $this->db->update('users', array('delete_status' => 0));             
        return true;
    }

    public function user_details($user_id)
    {       
  $this->db->select('users.*')->order_by('users.id','asc')->where('users.id', $user_id);
  $users = $this->db->get('users');
  //echo $this->db->last_query();exit;    
        if($users->num_rows() > 0)
        {
            return $users->result();
        }
        return array();

    }

    public function change_user_status($user_id, $status)
    {        
        $this->db->where('id', $user_id);
        $this->db->update('users', array('status' => $status));
        if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($user_id, $message);  
        }            
        return true;
    }

    /*---------- /users ------------*/

     public function all_exams($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'name',
        );
        $search_1 = array
        (
            1 => 'name',
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('id')->from('exams')->where('delete_status', 1)->order_by('id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('*')->from('exams')->where('delete_status', 1)->order_by('id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }

   public function insert_exams($data)
    {
        $this->db->insert('exams', $data); 
        //echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_exams()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        $query = $this->db->get('exams'); 
        //var_dump($query);exit; 
        //echo $this->db->last_query();exit;      
        return $query->row();
    }

    public function update_exams($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('exams', $data);  
         //echo $this->db->last_query();exit;          
        return true;
    }

    public function delete_exams()
    {        
        $this->db->where('exam_id', $this->uri->segment(4));
        $result= $this->db->get('chapters')->result_array();
         //print_r($result);
         $id=array();
         foreach($result as $results){
             $id[]=$results['id'];
         }
        // print_r($id);
         //exit;
        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('exams', $data);
        
        $this->db->where('exam_id', $this->uri->segment(4));
        $this->db->update('subjects', $data);
        
        $this->db->where('exam_id', $this->uri->segment(4));
        $this->db->update('chapters', $data);
        
        //$this->db->where_in('chapter_id', $id);
        //$this->db->update('video_topics', $data);
        
        //$this->db->where_in('chapter_id', $id);
        //$this->db->update('chapters_slides', $data);
        $this->db->where('exam_id', $this->uri->segment(4));
        $this->db->update('video_topics', $data);

        $this->db->where('exam_id', $this->uri->segment(4));
        $this->db->update('chapters_slides', $data);

        $this->db->where('exam_id', $this->uri->segment(4));
        $this->db->update('chapters_upload_notes', $data);

        $this->db->where('course_id', $this->uri->segment(4));
        $this->db->update(' quiz_topics', $data);

        $this->db->where('course_id', $this->uri->segment(4));
        $this->db->update(' quiz_questions', $data);

        $this->db->where('course_id', $this->uri->segment(4));
        $this->db->update(' test_series_quiz', $data);

        $this->db->where('course_id', $this->uri->segment(4));
        $this->db->update(' test_series_questions', $data);
        return true;
    }

    public function change_exam_status($user_id, $status)
    {        
        $this->db->where('id', $user_id);
        $this->db->update('exams', array('status' => $status));
                 
        return true;
    }

    /*---------- /exams ------------*/



    
    

     /*---------- subjects ------------*/
    public function subjects()
    {   
        $this->db->order_by('id', 'asc');
        $this->db->where('subjects.delete_status', 1);
        $query = $this->db->get('subjects');      
        return $query->result();
    }
    
    public function all_subjects($pdata, $getcount=null)
    {    

      $columns = array
        (
            0 => 'subjects.subject_name',
                1 => 'exams.name'
        );

        $search_1 = array
        (
            1 => 'subjects.subject_name',
             2 => 'exams.name'


        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('subjects.id')->from('subjects')->join('exams', 'exams.id = subjects.exam_id')->where('subjects.delete_status', 1)->where('exams.delete_status', 1)->order_by('subjects.id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('subjects.*, exams.name')->from('subjects')->join('exams', 'exams.id = subjects.exam_id')->where('subjects.delete_status', 1)->where('exams.delete_status', 1)->order_by('subjects.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;
        }
        return $result;
    }

     public function exams()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('exams.delete_status', 1);
       
        $query = $this->db->get('exams');      
        return $query->result();
    }

    public function insert_subjects($data)
    {
        $this->db->insert('subjects', $data);
       // echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_subjects()
    {
        $data = array('delete_status' => 0);
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        //echo $this->db->last_query();exit;
        $query = $this->db->get('subjects', $data);       
        return $query->row();
    }

    public function update_subjects($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('subjects', $data); 
       //echo $this->db->last_query();exit;            
        return true;
    }

    public function delete_subjects()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('subjects', $data);             
        return true;
    }

        public function get_exams()
    {
        $this->db->where('delete_status', 1);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('exams');      
        return $query->result();
    }

    public function get_submain($exam_id)
    {
        //$this->db->order_by('id', 'asc');
        $this->db->where('delete_status', 1);
        $this->db->where('course_id', $exam_id);
        $query = $this->db->get('subjects');      
        return $query->result_array();
    }


    public function gets_subjects()
    {   
        $this->db->order_by('id', 'asc');
        $this->db->where('delete_status', 1);
        $query = $this->db->get('subjects'); 
            //echo $this->db->last_query();exit;     
        return $query->result();
    }
    

    public function get_demo_video()
    {
       $this->db->order_by('id', 'asc');
        $query = $this->db->get('demo_video'); 
            //echo $this->db->last_query();exit;     
        return $query->result(); 
    }

    /*---------- /subjects ------------*/
      /*---------- chapters ------------*/

    public function change_chapter_status($id, $status)
    {        
        $this->db->where('id', $id);
        $this->db->update('chapters', array('status' => $status));
        /*if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($user_id, $message);  
        } */           
        return true;
    }
    
    public function all_chapters($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'chapter_name'
        );
        $search_1 = array
        (
            1 => 'exams.name',
            2 => 'subjects.subject_name',
            3 => 'chapters.chapter_name',
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] );
        }
        if($getcount)
        {
            return $this->db->select('chapters.id')->where('chapters.delete_status',1)->join('subjects', 'subjects.id = chapters.subject_id','left')->join('exams', 'exams.id = chapters.exam_id','left')->join('video_topics', 'video_topics.chapter_id = chapters.id','left')->from('chapters')->order_by('chapters.id','asc')->get()->num_rows();
        }
        else
        {
$this->db->select('chapters.*,chapters.chapter_name,subjects.subject_name,chapters.chapter_actorname,chapters.video_path,chapters.notespdf,exams.name as ename')->where('chapters.delete_status',1)->
join('subjects', 'subjects.id = chapters.subject_id','left')->
// join('video_topics', 'video_topics.chapter_id = chapters.id','left')->
// join('chapters_slides', 'chapters_slides.chapter_id = chapters.id','left')->
join('exams', 'exams.id = chapters.exam_id','left')->from('chapters')->order_by('chapters.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();  
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }
    public function send_push_notification($course_id,$image_path,$title,$message = NULL, $user_id, $type)
    {
        date_default_timezone_set("Asia/Kolkata");
        $reg_ids = array();
        $ios_reg_ids = array();

        $this->db->select("DISTINCT(user_id)");
     
        $multipleWhere = ['delete_status' => 1, 'exam_id' => $course_id];
          $this->db->where($multipleWhere);
          
        $user_exams = $this->db->get("users_exams");
        $ue_data=$user_exams->result_array();

       // echo '<pre>';print_r($ue_data);exit;
        if(!empty($ue_data)){
        foreach( $ue_data as $udata){
            $user_ids[]=$udata['user_id'];
        }
       }else{ $user_ids = array();}

        if($type == "many")
        {
            // $this->db->where_in('id', $user_id);
        }
        else
        {
            $this->db->where('id', $user_id);
        }
        $this->db->select("id, token, ios_token"); 
        $this->db->where_in('id',$user_ids);
               
        /*if($notification == "ping")
        {
            $this->db->where('ping_notifications', 'on');
        }
        else
        {
            $this->db->where('notifications', 'on');
        }*/
        $users = $this->db->get("users");
       // echo $this->db->last_query();exit;
        $r = array();       
        if($users->num_rows() > 0)
        {
            $result =  $users->result();
            foreach($result as $r)
            {
                // if($post_type == "friend_requests")
                // {
                //     $message = $r->name.' '.$message;
                // }
                if(!empty($r->ios_token) && $r->ios_token != "-" && $r->ios_token != "")
                {
                    array_push($ios_reg_ids, $r->ios_token);
                }
                if(!empty($r->token) && $r->token != "-" && $r->token != "")
                {
                    array_push($reg_ids, $r->token);
                }
                // $this->db->insert('notifications', array('user_id' => $r->id, 'title' => $title, 'message' => $message, 'post_id' => $section_id, 'type' => $notification, 'created_on' => date('Y-m-d H:i:s')));
                //echo $this->db->last_query();exit;
           
           
           
            }
            
            
        }
        //$rowsMsg[] = $message;
        $ios_message = $message;
        //$jsonData = json_encode(array('json' => $rowsMsg));            
        $message = array('title' => $title, 'message' => $message,'image'=>$image_path);
        //var_dump($message);exit;
        //var_dump($reg_ids);
    
     $chunkSize = 900;    
        
    $noOfTimesLoop = $reg_ids%$chunkSize + 1;   
    
   
    
   for ($x = 0; $x < $noOfTimesLoop; $x++) {
       
       
       
   $this->sendAndroidNotification(array_slice($reg_ids, $x*$chunkSize, $chunkSize), $message);
   
   
   }
    
        
        
        //print_r($pushStatus);
        //$iosPushStatus = $this->sendIosNotification($ios_reg_ids, $ios_message);
        return true;
    }

    public function sendAndroidNotification($tokens, $message) 
    {
        $url = 'https://fcm.googleapis.com/fcm/send';
        $fields = array(
             'registration_ids' => $tokens,
             'data' => $message
            );

        $headers = array(
           // 'Authorization:key = AIzaSyCl8zppJLCKPRiy4vxu7kx0KOqkoPAktAo',
            'Authorization:key = AAAAVzI0xoI:APA91bHcBbfCrtJLib1EWTNzu_9-kNQZF1woQVvNAlGR_6Jf9EnFxqTWnakP6L8qfdOUCIXKnYI5MGfIUUL-6YzuEc-iXIGZ1G3Jd_qsLkUOo6kWMD3EBwq26f5MzCfRkLlO2l93OB_M',
            'Content-Type: application/json'
        );
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);           
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
        //Print error if any
		//	 if(curl_errno($ch))
		//	 {
		//	 	echo 'error:' . curl_error($ch);exit;
		//	 }		
			// curl_close($ch);	
        curl_close($ch);
        //var_dump($result);
        return $result;
    }
    public function sendIosNotification($tokens, $message)
    {
        // API access key from Google FCM App Console
        define( 'API_ACCESS_KEY', 'AAAA-Eoxa6Q:APA91bG8iO-XcAp8gm4GahyWGbSRfX_Z1fZFiY-xf0ApiU1Xb9BrS7-cNr9Fs87yOz9JV8paqDty5gpmL7mmUPvfWvkU3sTMhhdQBqAuMpDIUbkJAJ-II3EZvQ9Os_yf_Dcx4M2UGEmV' );
        $fcmMsg = array(
            'body' => $message,
            'title' => 'This is title #1',
            'sound' => "default",
            'color' => "#203E78" 
        );  

        // 'to' => $singleID ;  // expecting a single ID
        // 'registration_ids' => $registrationIDs ;  // expects an array of ids
        // 'priority' => 'high' ; // options are normal and high, if not set, defaults to high.
        $fcmFields = array(
            'registration_ids' => $tokens,
            'priority' => 'high',
            'notification' => $fcmMsg
        );

        $headers = array(
            'Authorization: key=' . API_ACCESS_KEY,
            'Content-Type: application/json'
        );
         
        $ch = curl_init();
        curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
        curl_setopt( $ch,CURLOPT_POST, true );
        curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
        curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fcmFields ) );
        $result = curl_exec($ch );
        curl_close( $ch );
        //echo $result . "\n\n";//exit;
        return true;
    }

    /*---------- /chapters ------------*/

    public function insert_chapters($data)
    {
        $this->db->insert('chapters', $data); 
       //echo $this->db->last_query();exit;        
       return $this->db->insert_id();
        //return true;
    }

      public function edit_chapters()
    {
        $this->db->order_by('chapters.id', 'asc');
        $this->db->where('chapters.id', $this->uri->segment(4));
        //var_dump($query);exit;
         //echo $this->db->last_query();exit;
        $this->db->join('exams','exams.id=chapters.exam_id');
        $this->db->join('subjects','subjects.id=chapters.subject_id');
        // $this->db->join('video_topics','chapters.id=video_topics.chapter_id');
        $this->db->select('chapters.*,subjects.subject_name,exams.name as exam_name');
        $chapter = $this->db->get('chapters')->row();

        if(!empty($chapter)){
            // $this->db->order_by('id', 'asc');
            $this->db->where('chapter_id', $chapter->id);
            $slides = $this->db->get('chapters_slides');
            $slides = $slides->result_array();
        }
        if(!empty($chapter)){
            // $this->db->order_by('id', 'asc');
            $this->db->where('chapter_id', $chapter->id);
            $upload_notes = $this->db->get('chapters_upload_notes');
            $upload_notes = $upload_notes->result_array();
        }
        if(!empty($chapter)){
            // $this->db->order_by('id', 'asc');
            $this->db->where('chapter_id', $chapter->id);
            $video_topics = $this->db->get('video_topics');
            $video_topics = $video_topics->result_array();
        }

        // echo "<pre>";print_r($chapter);exit;
        return array('chapter'=>$chapter,'slides'=>$slides,'video_topics'=>$video_topics,'upload_notes'=>$upload_notes);
    }

    public function update_chapters($data, $id)
    {
        //$this->db->where('exam_id', $id);
        $this->db->where('id', $id);
        $this->db->update('chapters', $data);
       // echo $this->db->last_query();exit;       
        return true;
    }
    public function delete_chapters()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('chapters', $data);             
        return true;
    }
    public function get_subjects()
    {
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('subjects');      
        return $query->result();
    }
    
     public function get_subjects_videos()
    {
       
     $where = '(delete_status=1 and (category_type =2 or category_type=0))';
       $this->db->where($where);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('subjects');      
        return $query->result();
    }
    



    public function chapter_details($chapter_id)
    {       
  $this->db->select('chapters.*,,subjects.subject_name')->join('subjects', 'subjects.id = chapters.subject_id')->order_by('chapters.id','asc')->where('chapters.id', $chapter_id);
  $users = $this->db->get('chapters');
  //echo $this->db->last_query();exit;    
        if($users->num_rows() > 0)
        {
            return $users->result();
        }
        return array();

    }

    public function chapterdemo_details($chapter_id)
    {       
         $this->db->select('subjects.*,subjects.subject_name,subjects.video_path,chapters.id,chapters.chapter_name,chapters.chapter_actorname,chapters.notespdf,chapters.suggested_videos')->join('chapters', 'chapters.subject_id = subjects.id')->order_by('subjects.id','asc')->where('subjects.delete_status', 1);
  $users = $this->db->get('subjects');
  //echo $this->db->last_query();exit;    
        if($users->num_rows() > 0)
        {
            return $users->result();
        }
        return array();

    }

     

 public  function change_testaccess_status($status)
     {
        $this->db->update('plan_details', array('tests_access' => $status));
        if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($vendor_id, $message);  
        }            
        return true;
     }

     public  function change_videoaccess_status()
     {

        $this->db->update('plan_details', array('status' => $status));
        if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //echo $this->db->last_query();exit;
            //$this->send_notifications($vendor_id, $message);  
        }            
        return true;
     }

      public  function change_qbankaccess_status($status)
     {
        $this->db->update('plan_details', array('status' => $status));
        if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($vendor_id, $message);  
        }            
        return true;
        //echo $this->db->last_query();exit;
     }
     


 public function change_master_status($vendor_id, $status)
    {        
        $this->db->where('id', $vendor_id);
        $this->db->update('vendors', array('status' => $status));
        if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($vendor_id, $message);  
        }            
        return true;
    }

     

     /*--------chapter-------------*/
   



  /*---------- chapters_slides ------------*/
    
    public function all_chapters_slides($pdata, $getcount=null)
    {
        $columns = array
        (
             0 => 'chapters.chapter_name'
        );
        $search_1 = array
        (
             1 => 'chapters.chapter_name'
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] );
        }
        if($getcount)
        {
            return $this->db->select('chapters_slides.id')
            ->from('chapters_slides')->join('chapters', 'chapters.id = chapters_slides.chapter_id')->join('exams', 'exams.id = chapters_slides.exam_id','left')->join('subjects', 'subjects.id = chapters_slides.subject_id','left')->where('chapters_slides.delete_status', 1)->order_by('chapters_slides.id','asc')->get()->num_rows();
        }
        else
        {
        $this->db->select('chapters_slides.*,chapters.chapter_name,exams.name as ename,subjects.subject_name as sname')->join('chapters', 'chapters.id = chapters_slides.chapter_id','left')->join('exams', 'exams.id = chapters_slides.exam_id','left')->join('subjects', 'subjects.id = chapters_slides.subject_id','left')->from('chapters_slides')->where('chapters_slides.delete_status', 1)->order_by('chapters_slides.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get();
        //echo $this->db->last_query();exit;
        $result=$result->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }    

    /*---------- /chapters_slides ------------*/
 public function chapters()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('chapters.delete_status', 1);
       
        $query = $this->db->get('chapters');      
        return $query->result();
    }
     public function chapters_slides()
    {
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('chapters_slides');      
        return $query->result_array();
    }

     public function get_chapters()
    {
          $this->db->where('delete_status', 1);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('chapters');  
       //echo $this->db->last_query();exit;     
        return $query->result();
    }


      public function insert_chapters_slides($data)
    {
        $this->db->insert('chapters_slides', $data); 
        //echo $this->db->last_query();exit;            
        return true;
    }

      public function edit_chapters_slides()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        $query = $this->db->get('chapters_slides');
         //echo $this->db->last_query();exit;        
        return $query->row();
    }
    
    public function edit_chapters_slidess($id)
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $id);
        $query = $this->db->get('chapters_slides');
         //echo $this->db->last_query();exit;        
        return $query->row();
    }
    public function gets_chapters_slides()
    {

        $this->db->order_by('id', 'asc');
        $query = $this->db->get('chapters_slides');      
        return $query->result();


    }

    public function update_chapters_slides($data, $id)
    {
        $this->db->where('chapters_slides.id', $id);
        $this->db->update('chapters_slides', $data); 
       // echo $this->db->last_query();exit;             
        return true;
    }
   public function delete_chapters_slides()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('chapters_slides', $data);
        //echo $this->db->last_query();exit;             
        return true;
    }



     /*---------- notifications ------------*/
    
    public function all_notifications($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'title'
        );
        $search_1 = array
        (
            1 => 'title'
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] );
        }
        if($getcount)
        {
            return $this->db->select('notifications.id')->from('notifications')->where('notifications.delete_status', 1)->order_by('notifications.id','asc')->get()->num_rows();
        }
        else
        {
            $this->db->select('notifications.*')->from('notifications')->where('notifications.delete_status', 1)->order_by('notifications.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }    

    /*---------- /notifications ------------*/ 

    public function insert_notifications($data)
    {
        $this->db->insert('notifications', $data); 
       // echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_notifications()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        $query = $this->db->get('notifications'); 
        //var_dump($query);exit; 
        //echo $this->db->last_query();exit;      
        return $query->row();
    }

    public function update_notifications($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('notifications', $data);  
         //echo $this->db->last_query();exit;          
        return true;
    }

    public function delete_notifications()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('notifications', $data);             
        return true;
    }
    
     public function all_faculty($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'faculty_details.name',
             1 => 'faculty_details.title',
               2 => 'faculty_details.specialisation'
        );
        $search_1 = array
        (
            1 => 'exams.name',
            2 => 'faculty_details.name',
            3 => 'faculty_details.title',
            4 => 'faculty_details.specialisation'
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] );
        }
        if($getcount)
        {
            return $this->db->select('faculty_details.id')->from('faculty_details')->join('exams', 'exams.id = faculty_details.exam_id','left')->where('faculty_details.delete_status','1')->order_by('faculty_details.id','asc')->get()->num_rows();
        }
        else
        {
 $this->db->select('faculty_details.*,exams.name as ename')->from('faculty_details')->join('exams', 'exams.id = faculty_details.exam_id','left')->where('faculty_details.delete_status', 1)->order_by('faculty_details.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }    

    /*---------- /faculty ------------*/
    public function get_faculty()
    {
        $this->db->order_by('faculty_id', 'asc');
        $query = $this->db->get('faculty_details');      
        return $query->result_array();
    }

public function insert_faculty($data)
    {
        $this->db->insert('faculty_details', $data);
       // echo $this->db->last_query();exit;            
        return true;
    }

     public function update_faculty($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('faculty_details', $data);      
           return true;

    }
    public function delete_faculty()
    {        
        
         $data = array('delete_status' => 0);
         $this->db->where('id', $this->uri->segment(4));
         $this->db->update('faculty_details', $data);
        // echo $this->db->last_query();exit;

        return true;
    }

    public function change_faculty_status($faculty_id, $status)
    {        
        $this->db->where('faculty_id', $faculty_id);
        $this->db->update('faculty_details', array('status' => $status));
        if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($user_id, $message);  
        }            
        return true;
    }

    /*---------- /faculty ------------*/

 public function all_banners($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'image'
        );
        $search_1 = array
        (
           1 => 'exams.name'
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] );
        }
        if($getcount)
        {
            return $this->db->select('banners.id')->from('banners')->join('exams', 'exams.id = banners.exam_id')->where('banners.delete_status', 1)->order_by('banners.id','asc')->get()->num_rows();
        }
        else
        {
 $this->db->select('banners.*,exams.name')->join('exams', 'exams.id = banners.exam_id')->from('banners')->where('banners.delete_status', 1)->order_by('banners.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }  
    
    
    public function get_admin_details($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('admin');      
        return $query->result();
    }

    /*---------- /banners ------------*/
    public function get_banners()
    {
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('banners');      
        return $query->result();
    }

     public function delete_banners()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('banners', $data);  
       // echo $this->db->last_query();exit;             
        return true;
    }

    public function insert_banners($data)
    {
        $this->db->insert('banners', $data);
       //echo $this->db->last_query();exit;            
        return true;
    }

     public function updatepassword($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('admin', $data); 
       // echo $this->db->last_query();exit;     
            return true;

    }

    public function change_banner_status($banner_id, $status)
    {        
        $this->db->where('id', $banner_id);
        $this->db->update('banners', array('status' => $status));
        if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($user_id, $message);  
        }            
        return true;
    }

    /*---------- /banners ------------*/

   
    /*---------- / Image Gallery ------------*/

     public function all_imageGallery($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'note'
        );
        $search_1 = array
        (
           1 => 'note'
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] );
        }
        if($getcount)
        {
            return $this->db->select('images_gallery.id')->from('images_gallery')->order_by('images_gallery.id','asc')->get()->num_rows();
        }
        else
        {
        $this->db->select('images_gallery.*')->from('images_gallery')->order_by('images_gallery.id','desc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }  


    public function get_images_gallery($id)
    {
        $this->db->select('*');
        $this->db->where('id', $id);

        $query = $this->db->get('images_gallery');      
        return $query->row_array();
    }

     public function delete_images_gallery()
    {        
        $res=$this->get_images_gallery($this->uri->segment(4));
        $this->db->where('id', $this->uri->segment(4));
       $delete= $this->db->delete('images_gallery');  
       // echo $this->db->last_query();exit;             
       if($delete){
         if($res['image'] !=''){
            $file = './'.$res['image'];
                if(is_file($file))
                unlink($file);
         }
        }
         return true;
    }

    public function insert_images_gallery($data)
    {
        $this->db->insert('images_gallery', $data);
       //echo $this->db->last_query();exit;            
        return true;
    }
    public function edit_images_gallery()
     {
         $this->db->order_by('id', 'asc');
         $this->db->where('id', $this->uri->segment(4));
         $query = $this->db->get('images_gallery'); 
         //var_dump($query);exit; 
         //echo $this->db->last_query();exit;      
         return $query->row();
     }

     public function update_images_gallery($data, $id) {
        $this->db->where('id', $id);
        $this->db->update('images_gallery', $data);
        return true;
    }

    
/*---------- Image Gallery ------------*/

     /*---------- plandetails ------------*/
    
    public function all_plandetails($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'plan_name'
        );
        $search_1 = array
        (
            1 => 'plan_name',
            2 => 'plan_details.plan_type'
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] );
        }
        if($getcount)
        {
    return $this->db->select('plan_details.*')->from('plan_details')->where('delete_status',1)->order_by('plan_details.id','asc')->get()->num_rows();
        }
        else
        {
            $this->db->select('plan_details.*')->from('plan_details')->where('delete_status',1)->order_by('plan_details.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }    

    /*---------- /plandetails ------------*/

        public function insert_plandetails($data)
    {
        $this->db->insert('plan_details', $data);
       //echo $this->db->last_query();exit;            
        return true;
    }

    
     public function get_morecoupons()
    {
        $this->db->where('delete_status', 1);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('coupons');      
        return $query->result();
    }

    public function update_plandetails($data, $plan_id) {
        $this->db->where('id', $plan_id);
        $this->db->update('plan_details', $data);
        return true;
    }
   
    public function edit_plandetails()
    {
       // $data = array('delete_status' => 0);
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        //echo $this->db->last_query();exit;
        $query = $this->db->get('plan_details');       
        return $query->row();
    }



    public function delete_plandetails()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('plan_details', $data);    
          //echo $this->db->last_query();exit;
        return true;
    }

     public function gets_plandetails()
    {
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('plan_details');      
        return $query->result();
    }

    /*---------- coupons ------------*/
    
    public function all_coupons($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'coupon_code',
        );
        $search_1 = array
        (
            1 => 'coupon_code',
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('id')->from('coupons')->where('delete_status', 1)->order_by('id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('*')->from('coupons')->where('delete_status', 1)->order_by('id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }

    public function insert_coupons($data)
    {
        $this->db->insert('coupons', $data); 
     //echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_coupons()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        $query = $this->db->get('coupons');      
        return $query->row();
    }

    public function get_coupons()
    {
          $this->db->where('delete_status', 1);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('coupons');      
        return $query->result();
    }

    public function update_coupons($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('coupons', $data);
    // echo $this->db->last_query();exit;               
        return true;
    }

    public function delete_coupons()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('coupons', $data);    
        
        $this->db->where('coupon_id', $this->uri->segment(4));
        $this->db->update('plan_details', $data);
        return true;
    }

    /*---------- /coupons ------------*/

     public function all_payments($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'total_amount'
        );
        $search_1 = array
        (
            1 => 'total_amount'
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] );
        }
        if($getcount)
        {
            return $this->db->select('payments.id')->from('payments')->where('delete_status', 1)->order_by('id','asc')->get()->num_rows();
        }
        else
        {
 $this->db->select('payments.*')->from('payments')->where('delete_status', 1)->order_by('id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }    

    /*---------- /payments ------------*/
    public function get_payments()
    {
          $this->db->where('delete_status', 1);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('payments');      
        return $query->result();
    }

     public function delete_payments($payment_id)
    {        
        $this->db->where('id', $payment_id);
        $this->db->update('payments', array('delete_status' => 0));             
        return true;
    }

    public function change_payments_status($payment_id, $status)
    {        
        $this->db->where('id', $payment_id);
        $this->db->update('payments', array('status' => $status));
        //echo $this->db->last_query();exit;
        if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($user_id, $message);  
        }            
        return true;
    }

    /*---------- /payments ------------*/

     /*---------- testseries ------------*/
    
     public function all_testseries($pdata, $getcount=null)
     {
         $columns = array
         (
             0 => 'title',
         );
         $search_1 = array
         (
             1 => 'title',
         );        
         if(isset($pdata['search_text_1'])!="")
         {
             $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
         }
         if($getcount)
         {
             return $this->db->select('id')->from('testseries')->order_by('id','asc')->get()->num_rows();  
         }
         else
         {
             $this->db->select('*')->from('testseries')->order_by('id','asc');
         }
         if(isset($pdata['length']))
         {
             $perpage = $pdata['length'];
             $limit = $pdata['start'];
             $generatesno=$limit+1;
             $orderby_field = $columns[$pdata['order'][0]['column'] ];   
             $orderby = $pdata['order']['0']['dir'];
             $this->db->order_by($orderby_field,$orderby);
             $this->db->limit($perpage,$limit);
         }
         else
         {
             $generatesno = 0;
         }
         $result = $this->db->get()->result_array();       
         foreach($result as $key=>$values)
         {
             $result[$key]['sno'] = $generatesno++;           
            
         }
         return $result;
     }
 
    public function insert_testseries($data)
     {
         $this->db->insert('testseries', $data); 
      //echo $this->db->last_query();exit;            
         return true;
     }
 
     public function edit_testseries()
     {
         $this->db->order_by('id', 'asc');
         $this->db->where('id', $this->uri->segment(4));
         $query = $this->db->get('testseries'); 
         //var_dump($query);exit; 
         //echo $this->db->last_query();exit;      
         return $query->row();
     }
 
     public function update_testseries($data, $id)
     {
         $this->db->where('id', $id);
         $this->db->update('testseries', $data);  
          //echo $this->db->last_query();exit;          
         return true;
     }
 
     public function delete_testseries()
     {        
         $data = array('delete_status' => 0);
         $this->db->where('id', $this->uri->segment(4));
         $this->db->update('testseries', $data);             
         return true;
     }
 
     /*---------- /testseries ------------*/


    public function all_test_series_categories($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'title',
        );
        $search_1 = array
        (
            1 => 'title',
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('id')->from('test_series_categories')->order_by('id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('*')->from('test_series_categories')->order_by('id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }

   public function insert_test_series_categories($data)
    {
        $this->db->insert('test_series_categories', $data); 
     //   echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_test_series_categories()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        $query = $this->db->get('test_series_categories'); 
        //var_dump($query);exit; 
        //echo $this->db->last_query();exit;      
        return $query->row();
    }

    public function update_test_series_categories($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('test_series_categories', $data);  
        // echo $this->db->last_query();exit;          
        return true;
    }

    public function delete_test_series_categories()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('test_series_categories', $data); 
     // $this->db->last_query();exit();            
        return true;
    }

    /*---------- /test_series_categories ------------*/

    /*---------- topics ------------*/
    public function topics()
    {   
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('quiz_topicss');      
        return $query->result();
    }
    
    public function all_topics($pdata, $getcount=null)
    {    

      $columns = array
        (
            0 => 'quiz_topics.topic_name',
                1 => 'quiz_topics.title'
        );

        $search_1 = array
        (
            1 => 'exams.name',
             2 => 'subjects.subject_name',
             3 =>'quiz_topics.topic_name',
             4 =>'quiz_topics.title',
             5 =>'quiz_topics.quiz_type',
             


        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('quiz_topics.id')->join('exams', 'exams.id = quiz_topics.course_id')->join('subjects', 'subjects.id = quiz_topics.subject_id')->from('quiz_topics')->order_by('quiz_topics.id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('quiz_topics.*,exams.name  as ename,subjects.subject_name as sname')->join('exams', 'exams.id = quiz_topics.course_id')->join('subjects', 'subjects.id = quiz_topics.subject_id')->from('quiz_topics')->order_by('quiz_topics.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;
        }
        return $result;
    }

     public function mainexams()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('exams.delete_status', 1);
       
        $query = $this->db->get('exams');      
        return $query->result();
    }

    public function insert_topics($data)
    {
        $this->db->insert('quiz_topics', $data);
       // echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_topics()
    {
        $this->db->order_by('quiz_topics.id', 'asc');
        $this->db->where('quiz_topics.id', $this->uri->segment(4));
        $this->db->join('exams', 'exams.id = quiz_topics.course_id');
        $this->db->join('subjects', 'subjects.id = quiz_topics.subject_id');
        $this->db->select('quiz_topics.*,exams.name  as course_name,subjects.subject_name as sname');
        $query = $this->db->get('quiz_topics');
          // var_dump($this->db->last_query());exit;
        return $query->row();
    }
    public function update_topics($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('quiz_topics', $data); 
       //echo $this->db->last_query();exit;            
        return true;
    }
    public function delete_topics()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('quiz_topics', $data);             
        return true;
    }
    public function change_topic_status($id, $status)
    {        
        $this->db->where('id', $id);
        $this->db->update('quiz_topics', array('status' => $status));
        /*if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($user_id, $message);  
        } */           
        return true;
    }


        public function get_mainexams()
    {
        $this->db->where('delete_status', 1);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('exams');      
        return $query->result();
    }

    public function get_mainsubjects()
    {
        
         $where = '(delete_status=1 and (category_type =2 or category_type=0))';
       $this->db->where($where);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('subjects'); 
        //$this->db->last_query();exit();     
        return $query->result();
    }


    public function gets_topics()
    {   
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('quiz_topics'); 
            //echo $this->db->last_query();exit;     
        return $query->result();
    }

  public function edit_topicss()
  {
    $this->db->order_by('id', 'asc');
    $query = $this->db->get('quiz_topics');      
    return $query->result();
  }

    /*---------- /topics ------------*/

    
      /*---------- quiz_questions ------------*/
      public function quiz_questions()
      {   
          $this->db->order_by('id', 'asc');
          $query = $this->db->get('quiz_questions');      
          return $query->result();
      }
      
      public function all_quiz_questions($pdata, $getcount=null)
      {    
  
        $columns = array
          (
              0 => 'quiz_questions.question'
          );
  
          $search_1 = array
          (
            1 => 'exams.name',
            2 => 'subjects.subject_name',
            3 =>'quiz_topics.topic_name',  
            4 => 'quiz_questions.question',
            5 => 'quiz_questions.answer',
            6 => 'quiz_questions.question',

  
  
          );        
          if(isset($pdata['search_text_1'])!="")
          {
              $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
          }
          if($getcount)
          {
              return $this->db->select('quiz_questions.id')->join('exams', 'exams.id = quiz_questions.course_id')->join('subjects', 'subjects.id = quiz_questions.subject_id')->join('quiz_topics', 'quiz_topics.id = quiz_questions.topic_id')->from('quiz_questions')->order_by('quiz_questions.id','asc')->get()->num_rows();  
          }
          else
          {
              $this->db->select('quiz_questions.*,exams.name  as ename,subjects.subject_name as sname,quiz_topics.topic_name as qtname')
              ->join('exams', 'exams.id = quiz_questions.course_id')
              ->join('subjects', 'subjects.id = quiz_questions.subject_id')
              ->join('quiz_topics', 'quiz_topics.id = quiz_questions.topic_id')
              ->from('quiz_questions')->order_by('quiz_questions.id','asc');
          }
          if(isset($pdata['length']))
          {
              $perpage = $pdata['length'];
              $limit = $pdata['start'];
              $generatesno=$limit+1;
              $this->db->limit($perpage,$limit);
          }
          else
          {
              $generatesno = 0;
          }
          $result = $this->db->get()->result_array();       
          foreach($result as $key=>$values)
          {
              $result[$key]['sno'] = $generatesno++;
          }
          return $result;
      }
  
      
  
      public function insert_quiz_questions($data)
      {
          $this->db->insert('quiz_questions', $data);
        //  echo $this->db->last_query();exit;            
          return true;
      }
  
      public function edit_quiz_questions()
      {
          $this->db->order_by('quiz_questions.id', 'asc');
          $this->db->where('quiz_questions.id', $this->uri->segment(4));
          $this->db->join('exams', 'exams.id = quiz_questions.course_id');
           $this->db->join('subjects', 'subjects.id = quiz_questions.subject_id');
          $this->db->join('quiz_topics', 'quiz_topics.id = quiz_questions.topic_id');
          $this->db->select('quiz_questions.*,exams.name  as course_name,subjects.subject_name as sname,quiz_topics.topic_name as qtname');
          $query = $this->db->get('quiz_questions');
        //   var_dump($this->db->last_query());exit;
          return $query->row();
      }

      public function edit_quiz_questionsoptions()
      {
          // $this->db->order_by('id', 'asc');
          $this->db->where('question_id', $this->uri->segment(4));
          $query = $this->db->get('quiz_options');
          //echo $this->db->last_query();exit;
          return $query->result_array();
      }
      
      
  
      public function update_quiz_questions($data, $id)
      {
          $this->db->where('id', $id);
          $this->db->update('quiz_questions', $data); 
         //echo $this->db->last_query();exit;            
          return true;
      }
  
      public function delete_quiz_questions()
      {        
          $data = array('delete_status' => 0);
          $this->db->where('id', $this->uri->segment(4));
          $this->db->update('quiz_questions', $data);             
          return true;
      }

  
      public function gets_quiz_questions()
      {   
          $this->db->order_by('id', 'asc');
          $query = $this->db->get('quiz_questions'); 
              //echo $this->db->last_query();exit;     
          return $query->result();
      }


      public function get_mainquiz_topics()
      {
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('quiz_topics'); 
         //   echo $this->db->last_query();exit;     
        return $query->result();
      }
  
      /*---------- /quiz_questions ------------*/




        /*---------- test_series_quiz ------------*/
    public function test_series_quiz()
    {   
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('test_series_quiz');      
        return $query->result();
    }
    
    public function get_quiz_topics_info($details){
        $this->db->order_by('id', 'asc');
        $this->db->where('course_id', $details['course_id']);
        $this->db->where('category_id', $details['category_id']);
        $this->db->select('id,title');
        $query = $this->db->get('test_series_quiz');
        return $query->result_array();
    }

    public function all_test_series_quiz($pdata, $getcount=null)
    {    

      $columns = array
        (
            0 => 'test_series_quiz.ascription',
               
        );

        $search_1 = array
        (
             1 => 'exams.name',
             2 => 'test_series_categories.title',
             3 =>'test_series_quiz.title',
             4 =>'test_series_quiz.quiz_type'


        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('test_series_quiz.id')->join('exams', 'exams.id = test_series_quiz.course_id')->join('test_series_categories', 'test_series_categories.id = test_series_quiz.category_id')->from('test_series_quiz')->order_by('test_series_quiz.id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('test_series_quiz.*,exams.name as ename,test_series_categories.title as tcat')->join('exams', 'exams.id = test_series_quiz.course_id')->join('test_series_categories', 'test_series_categories.id = test_series_quiz.category_id')->from('test_series_quiz')->order_by('test_series_quiz.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;
        }
        return $result;
    }

     public function mainsexams()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('exams.delete_status', 1);
       
        $query = $this->db->get('exams');      
        return $query->result();
    }

    public function insert_test_series_quiz($data)
    {
        $this->db->insert('test_series_quiz', $data);
       // echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_test_series_quiz()
    {
        $data = array('delete_status' => 0);
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        //echo $this->db->last_query();exit;
        $query = $this->db->get('test_series_quiz', $data);       
        return $query->row();
    }

    public function update_test_series_quiz($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('test_series_quiz', $data); 
      // echo $this->db->last_query();exit;   

        $this->db->where('quiz_id',$id);
        $update_questions_data =array('course_id' => $data['course_id']);
        $this->db->update('test_series_questions',$update_questions_data);         
        return true;
    }
    public function update_questionsCousres_data($data, $id){
        $this->db->where('quiz_id',$id);
        $update_questions_data = array('course_id' => $data['course_id']);
        $this->db->update('test_series_questions',$update_questions_data);         
        return true;
    }

    public function delete_test_series_quiz()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('test_series_quiz', $data);             
        return true;
    }
    public function change_test_series_qiuz_status($id, $status)
    {        
        $this->db->where('id', $id);
        $this->db->update('test_series_quiz', array('status' => $status));
        /*if($status == "Inactive")
        {
            $message = "Your account has been put on hold. Please contact administrator.";
            //$this->send_notifications($user_id, $message);  
        } */           
        return true;
    }

        public function get_mainimpexams()
    {
        $this->db->where('delete_status', 1);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('exams');      
        return $query->result();
    }

    public function get_test_series_categories()
    {
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('test_series_categories');      
        return $query->result();
    }


    public function gets_test_series_quiz()
    {   
        $this->db->order_by('id', 'asc');
        $query = $this->db->get('test_series_quiz'); 
            //echo $this->db->last_query();exit;     
        return $query->result();
    }

    /*---------- /test_series_quiz ------------*/


     /*---------- test_series_questions ------------*/
     public function test_series_questions()
     {   
         $this->db->order_by('que_number', 'asc');
         $query = $this->db->get('test_series_questions');      
         return $query->result();
     }
     
     public function all_test_series_questions($pdata, $getcount=null)
     {    
 
       $columns = array
         (
             0 => 'test_series_questions.question'
         );
 
         $search_1 = array
         (
             1 => 'exams.name',
             2=> 'test_series_categories.title',
             3 => 'test_series_quiz.title',
             4 => 'test_series_questions.question',
             5 => 'test_series_questions.answer'
 
 
         );        
         if(isset($pdata['search_text_1'])!="")
         {
             $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
         }
         if($getcount)
         {
             return $this->db->select('test_series_questions.id')->join('exams', 'exams.id = test_series_questions.course_id')->join('test_series_categories', 'test_series_categories.id = test_series_questions.category_id')->join('test_series_quiz', 'test_series_quiz.id = test_series_questions.quiz_id')->from('test_series_questions')->order_by('test_series_questions.que_number','asc')->get()->num_rows();  
         }
         else
         {
            $this->db->select('test_series_questions.*,exams.name as ename,test_series_quiz.title as qtitle,test_series_categories.title as tscat')->join('exams', 'exams.id = test_series_questions.course_id')->join('test_series_categories', 'test_series_categories.id = test_series_questions.category_id')->join('test_series_quiz', 'test_series_quiz.id = test_series_questions.quiz_id')->from('test_series_questions')->order_by('test_series_questions.que_number','asc');
            // $this->db->last_query();exit(); 
        }
         if(isset($pdata['length']))
         {
             $perpage = $pdata['length'];
             $limit = $pdata['start'];
             $generatesno=$limit+1;
             $this->db->limit($perpage,$limit);
         }
         else
         {
             $generatesno = 0;
         }
         $result = $this->db->get()->result_array();       
         foreach($result as $key=>$values)
         {
             $result[$key]['sno'] = $generatesno++;
         }
         return $result;
     }
 
     
 
     public function insert_test_series_questions($data)
     {
         $this->db->insert('test_series_questions', $data);
    //   echo $this->db->last_query();exit;            
         return $this->db->insert_id();
     }
 
     public function edit_test_series_questions()
     {
        $this->db->order_by('test_series_questions.id', 'asc');
        $this->db->where('test_series_questions.id', $this->uri->segment(4));
        $this->db->join('exams', 'exams.id = test_series_questions.course_id');
        $this->db->join('test_series_categories', 'test_series_categories.id = test_series_questions.category_id');
        $this->db->join('test_series_quiz', 'test_series_quiz.id = test_series_questions.quiz_id');
        /*$this->db->join('subjects', 'subjects.id = test_series_questions.subject_id');*/
        $this->db->select('test_series_questions.*,exams.name  as course_name,test_series_categories.title as cat_name,test_series_quiz.title as tname');
        $query = $this->db->get('test_series_questions');  
        // echo $this->db->last_query();exit;
              
         return $query->row();
     }

     public function edit_test_series_question_options(){
        $this->db->where('question_id', $this->uri->segment(4));
        $query = $this->db->get('test_series_options');
        return $query->result_array();
     }
 
     public function update_test_series_questions($data, $id)
     {
         $this->db->where('id', $id);
         $this->db->update('test_series_questions', $data); 
        //echo $this->db->last_query();exit;            
         return true;
     }
 
     public function delete_test_series_questions()
     {        
         $data = array('delete_status' => 0);
         $this->db->where('id', $this->uri->segment(4));
         $this->db->update('test_series_questions', $data);             
         return true;
     }
 
 
     public function gets_test_series_questions()
     {   
         $this->db->order_by('que_number', 'asc');
         $query = $this->db->get('test_series_questions'); 
             //echo $this->db->last_query();exit;     
         return $query->result();
     }


     public function get_mainquiz_test_series_questions()
     {
       $this->db->order_by('que_number', 'asc');
       $query = $this->db->get('test_series_questions'); 
           //echo $this->db->last_query();exit;     
       return $query->result();
     }
 
     /*---------- /test_series_questions ------------*/


     
    
     /*---------- quiz_reports ------------*/
    public function quiz_reports()
    {   
        $this->db->order_by('id', 'asc');
      //  $this->db->where('quiz_reports.delete_status', 1);
        $query = $this->db->get('quiz_reports');      
        return $query->result();
    }
    
    public function all_quiz_reports($pdata, $getcount=null)
    {    

      $columns = array
        (
            0 => 'quiz_reports.reports'
        );

        $search_1 = array
        (
            1 => 'exams.name',
            2 => 'subjects.subject_name'
            


        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('quiz_reports.id')->join('exams', 'exams.id = quiz_reports.course_id')->join('subjects', 'subjects.id = quiz_reports.subject_id')->from('quiz_reports')->order_by('quiz_reports.id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('quiz_reports.*,exams.name as ename,subjects.subject_name as sname,quiz_topics.topic_name as qtitle,quiz_questions.question as qq,users.name as uname')->join('users', 'users.id = quiz_reports.user_id')->join('quiz_questions', 'quiz_questions.id = quiz_reports.question_id')->join('exams', 'exams.id = quiz_reports.course_id')->join('subjects', 'subjects.id = quiz_reports.subject_id')->join('quiz_topics', 'quiz_topics.id = quiz_reports.topic_id')->from('quiz_reports')->order_by('quiz_reports.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;
        }
        return $result;
    }

   

    public function insert_quiz_reports($data)
    {
        $this->db->insert('quiz_reports', $data);
       // echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_quiz_reports()
    {
        $data = array('delete_status' => 0);
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        //echo $this->db->last_query();exit;
        $query = $this->db->get('quiz_reports', $data);       
        return $query->row();
    }

    public function update_quiz_reports($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('quiz_reports', $data); 
       //echo $this->db->last_query();exit;            
        return true;
    }

    public function delete_quiz_reports()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('quiz_reports', $data);             
        return true;
    }

      

    public function gets_quiz_reports()
    {   
        $this->db->order_by('id', 'asc');
       // $this->db->where('delete_status', 1);
        $query = $this->db->get('quiz_reports'); 
            //echo $this->db->last_query();exit;     
        return $query->result();
    }
    

    
    /*---------- /quiz_reports ------------*/


    /*---------- feedback ------------*/
    public function feedback()
    {   
        $this->db->order_by('id', 'asc');
      //  $this->db->where('feedback.delete_status', 1);
        $query = $this->db->get('feedback');      
        return $query->result();
    }
    
    public function all_feedback($pdata, $getcount=null)
    {    

      $columns = array
        (
            0 => 'quiz_topic_reviews.ratings'
        );

        $search_1 = array
        (
            1 => 'exams.name',
            2 => 'subjects.subject_name',
            3 =>'quiz_topics.topic_name',  
            4 => 'quiz_topic_reviews.ratings',
            


        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('quiz_topic_reviews.id')->join('exams', 'exams.id = quiz_topic_reviews.course_id')->join('subjects', 'subjects.id = quiz_topic_reviews.subject_id')->join('quiz_topics', 'quiz_topics.id = quiz_topic_reviews.topic_id')->from('quiz_topic_reviews')->order_by('quiz_topic_reviews.id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('quiz_topic_reviews.*,exams.name as ename,subjects.subject_name as sname,quiz_topics.topic_name as qtitle,quiz_topic_reviews.ratings as ratre')->join('exams', 'exams.id = quiz_topic_reviews.course_id')->join('subjects', 'subjects.id = quiz_topic_reviews.subject_id')->join('quiz_topics', 'quiz_topics.id = quiz_topic_reviews.topic_id')->from('quiz_topic_reviews')->order_by('quiz_topic_reviews.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;
        }
        return $result;
    }

   

    public function insert_feedback($data)
    {
        $this->db->insert('feedback', $data);
       // echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_feedback()
    {
        $data = array('delete_status' => 0);
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        //echo $this->db->last_query();exit;
        $query = $this->db->get('feedback', $data);       
        return $query->row();
    }

    public function update_feedback($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('feedback', $data); 
       //echo $this->db->last_query();exit;            
        return true;
    }

    public function delete_feedback()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('feedback', $data);             
        return true;
    }

      

    public function gets_feedback()
    {   
        $this->db->order_by('id', 'asc');
       // $this->db->where('delete_status', 1);
        $query = $this->db->get('feedback'); 
            //echo $this->db->last_query();exit;     
        return $query->result();
    }
    

    
    /*---------- /feedback ------------*/

    /*---------- quiz_question_bookmarks ------------*/
    public function quiz_question_bookmarks()
    {   
        $this->db->order_by('id', 'asc');
      //  $this->db->where('quiz_question_bookmarks.delete_status', 1);
        $query = $this->db->get('quiz_question_bookmarks');      
        return $query->result();
    }
    
    public function all_quiz_question_bookmarks($pdata, $getcount=null)
    {    

      $columns = array
        (
            0 => 'quiz_question_bookmarks.id'
        );

        $search_1 = array
        (
            1 => 'exams.name',
            2 => 'subjects.subject_name',
            3 =>'quiz_topics.topic_name',  
        


        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('quiz_question_bookmarks.id')->join('users', 'users.id = quiz_question_bookmarks.user_id')->join('exams', 'exams.id = quiz_question_bookmarks.course_id')->join('subjects', 'subjects.id = quiz_question_bookmarks.subject_id')->join('quiz_topics', 'quiz_topics.id = quiz_question_bookmarks.topic_id')->join('quiz_questions', 'quiz_questions.id = quiz_question_bookmarks.question_id')->from('quiz_question_bookmarks')->order_by('quiz_question_bookmarks.id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('quiz_question_bookmarks.*,exams.name as ename,subjects.subject_name as sname,quiz_topics.topic_name as qtitle,users.name as uname,quiz_questions.question as qq')->join('users', 'users.id = quiz_question_bookmarks.user_id')->join('exams', 'exams.id = quiz_question_bookmarks.course_id')->join('subjects', 'subjects.id = quiz_question_bookmarks.subject_id')->join('quiz_topics', 'quiz_topics.id = quiz_question_bookmarks.topic_id')->join('quiz_questions', 'quiz_questions.id = quiz_question_bookmarks.question_id')->from('quiz_question_bookmarks')->order_by('quiz_question_bookmarks.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;
        }
        return $result;
    }

   

    public function insert_quiz_question_bookmarks($data)
    {
        $this->db->insert('quiz_question_bookmarks', $data);
       // echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_quiz_question_bookmarks()
    {
        $data = array('delete_status' => 0);
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        //echo $this->db->last_query();exit;
        $query = $this->db->get('quiz_question_bookmarks', $data);       
        return $query->row();
    }

    public function update_quiz_question_bookmarks($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('quiz_question_bookmarks', $data); 
       //echo $this->db->last_query();exit;            
        return true;
    }

    public function delete_quiz_question_bookmarks()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('quiz_question_bookmarks', $data);             
        return true;
    }

      

    public function gets_quiz_question_bookmarks()
    {   
        $this->db->order_by('id', 'asc');
       // $this->db->where('delete_status', 1);
        $query = $this->db->get('quiz_question_bookmarks'); 
            //echo $this->db->last_query();exit;     
        return $query->result();
    }
   
    /*---------- /quiz_question_bookmarks ------------*/


    public function all_examss($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'name',
        );
        $search_1 = array
        (
            1 => 'name',
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('id')->from('exams')->where('delete_status', 1)->order_by('id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('*')->from('exams')->where('delete_status', 1)->order_by('id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }

   public function insert_examss($data)
    {
        $this->db->insert('exams', $data); 
        //echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_examss()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        $query = $this->db->get('exams'); 
        //var_dump($query);exit; 
        //echo $this->db->last_query();exit;      
        return $query->row();
    }

    public function update_examss($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('exams', $data);  
         //echo $this->db->last_query();exit;          
        return true;
    }

    public function delete_examss()
    {        
        $this->db->where('exam_id', $this->uri->segment(4));
        $result= $this->db->get('chapters')->result_array();
         //print_r($result);
         $id=array();
         foreach($result as $results){
             $id[]=$results['id'];
         }
        // print_r($id);
         //exit;
        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('exams', $data);
        
        $this->db->where('exam_id', $this->uri->segment(4));
        $this->db->update('subjects', $data);
        
        $this->db->where('exam_id', $this->uri->segment(4));
        $this->db->update('chapters', $data);
        
        $this->db->where_in('chapter_id', $id);
        $this->db->update('video_topics', $data);
        
        $this->db->where_in('chapter_id', $id);
        $this->db->update('chapters_slides', $data);

        return true;
    }

    /*---------- /examss ------------*/


    public function all_examsss($pdata, $getcount=null)
    {
        $columns = array
        (
            0 => 'name',
        );
        $search_1 = array
        (
            1 => 'name',
        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
            return $this->db->select('id')->from('exams')->where('delete_status', 1)->order_by('id','asc')->get()->num_rows();  
        }
        else
        {
            $this->db->select('*')->from('exams')->where('delete_status', 1)->order_by('id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $orderby_field = $columns[$pdata['order'][0]['column'] ];   
            $orderby = $pdata['order']['0']['dir'];
            $this->db->order_by($orderby_field,$orderby);
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;           
           
        }
        return $result;
    }

   public function insert_examsss($data)
    {
        $this->db->insert('exams', $data); 
        //echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_examsss()
    {
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        $query = $this->db->get('exams'); 
        //var_dump($query);exit; 
        //echo $this->db->last_query();exit;      
        return $query->row();
    }

    public function update_examsss($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('exams', $data);  
         //echo $this->db->last_query();exit;          
        return true;
    }

    public function delete_examsss()
    {        
        $this->db->where('exam_id', $this->uri->segment(4));
        $result= $this->db->get('chapters')->result_array();
         //print_r($result);
         $id=array();
         foreach($result as $results){
             $id[]=$results['id'];
         }
        // print_r($id);
         //exit;
        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('exams', $data);
        
        $this->db->where('exam_id', $this->uri->segment(4));
        $this->db->update('subjects', $data);
        
        $this->db->where('exam_id', $this->uri->segment(4));
        $this->db->update('chapters', $data);
        
        $this->db->where_in('chapter_id', $id);
        $this->db->update('video_topics', $data);
        
        $this->db->where_in('chapter_id', $id);
        $this->db->update('chapters_slides', $data);

        return true;
    }

    /*---------- /examsss ------------*/

     /*---------- testseries_bookmarks ------------*/
    public function testseries_bookmarks()
    {   
        $this->db->order_by('id', 'asc');
      //  $this->db->where('testseries_bookmarks.delete_status', 1);
        $query = $this->db->get('test_series_bookmarks');      
        return $query->result();
    }
    
    public function all_testseries_bookmarks($pdata, $getcount=null)
    {    

      $columns = array
        (
            0 => 'test_series_bookmarks.id'
        );

        $search_1 = array
        (
            1 => 'exams.name',
         2 => 'test_series_categories.title'
            


        );        
        if(isset($pdata['search_text_1'])!="")
        {
            $this->db->like($search_1[$pdata['search_on_1']], $pdata['search_text_1'], $pdata['search_at_1'] ); 
        }
        if($getcount)
        {
return $this->db->select('test_series_bookmarks.id')->join('exams', 'exams.id = test_series_bookmarks.course_id')
            ->join('users', 'users.id = test_series_bookmarks.user_id')->join('test_series_categories', 'test_series_categories.id = test_series_bookmarks.category_id')->join('test_series_quiz', 'test_series_quiz.id = test_series_bookmarks.quiz_id')->join('test_series_questions', 'test_series_questions.id = test_series_bookmarks.question_id')->from('test_series_bookmarks')->order_by('test_series_bookmarks.id','asc')->get()->num_rows();  
         //   $this->db->last_query();exit();

        }
        else
        {
$this->db->select('test_series_bookmarks.*,users.name as uname,exams.name as ename,test_series_categories.title as tcname,test_series_quiz.title as tsqt,test_series_questions.question as tsqques')->join('users', 'users.id = test_series_bookmarks.user_id')->join('exams', 'exams.id = test_series_bookmarks.course_id')->join('test_series_categories', 'test_series_categories.id = test_series_bookmarks.category_id')->join('test_series_quiz', 'test_series_quiz.id = test_series_bookmarks.quiz_id')->join('test_series_questions', 'test_series_questions.id = test_series_bookmarks.question_id')->from('test_series_bookmarks')->order_by('test_series_bookmarks.id','asc');
        }
        if(isset($pdata['length']))
        {
            $perpage = $pdata['length'];
            $limit = $pdata['start'];
            $generatesno=$limit+1;
            $this->db->limit($perpage,$limit);
        }
        else
        {
            $generatesno = 0;
        }
        $result = $this->db->get()->result_array();       
        foreach($result as $key=>$values)
        {
            $result[$key]['sno'] = $generatesno++;
        }
        return $result;
    }

   

    public function insert_testseries_bookmarks($data)
    {
        $this->db->insert('test_series_bookmarks', $data);
       // echo $this->db->last_query();exit;            
        return true;
    }

    public function edit_testseries_bookmarks()
    {
        $data = array('delete_status' => 0);
        $this->db->order_by('id', 'asc');
        $this->db->where('id', $this->uri->segment(4));
        //echo $this->db->last_query();exit;
        $query = $this->db->get('test_series_bookmarks', $data);       
        return $query->row();
    }

    public function update_testseries_bookmarks($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('test_series_bookmarks', $data); 
       //echo $this->db->last_query();exit;            
        return true;
    }

    public function delete_testseries_bookmarks()
    {        
        $data = array('delete_status' => 0);
        $this->db->where('id', $this->uri->segment(4));
        $this->db->update('test_series_bookmarks', $data);             
        return true;
    }

      

    public function gets_testseries_bookmarks()
    {   
        $this->db->order_by('id', 'asc');
       // $this->db->where('delete_status', 1);
        $query = $this->db->get('test_series_bookmarks'); 
            //echo $this->db->last_query();exit;     
        return $query->result();
    }
    
    
     public function getUserId($mobile)
    {      
        
        

           $this->db ->where('mobile', $mobile);
   
              $query = $this->db->get('users');
              $result = $query->result_array();

               if(!empty($result))
                  return  $result;
             else   return null;

    }
    
      public function resetTestSeries($quizId,$mobile){
          
          $user =  $this->getUserId($mobile);
          
          if($user == null)
          return false;
        
      $this->db ->where('user_id',$user[0]['id']);

        $this ->db ->where('quiz_id', $quizId);
         
        $delete = $this->db ->delete(array('user_assigned_testseries','test_series_marks','test_series_answers'));
        
        return $delete;
        
    }
       
    /*---------- /testseries_bookmarks ------------*/

     
     }
?>